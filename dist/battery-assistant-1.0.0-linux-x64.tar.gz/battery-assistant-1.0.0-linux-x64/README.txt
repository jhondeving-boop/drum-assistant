╔══════════════════════════════════════════════════════════╗
║           🔋 BATTERY ASSISTANT v1.0.0                    ║
╠══════════════════════════════════════════════════════════╣
║                                                          ║
║  Asistente de batería con notificaciones de audio        ║
║                                                          ║
║  INSTALACIÓN:                                            ║
║  ────────────                                            ║
║  1. Extrae este archivo                                  ║
║  2. Abre una terminal en la carpeta extraída             ║
║  3. Ejecuta: sudo ./install.sh                           ║
║                                                          ║
║  CARACTERÍSTICAS:                                        ║
║  ─────────────────                                       ║
║  🔌 Aviso al conectar el cargador                        ║
║  🔋 Aviso al desconectar el cargador                     ║
║  ⚠️  Alerta de batería baja (< 20%)                       ║
║  ✅ Aviso de carga completa (> 95%)                       ║
║                                                          ║
║  Se inicia automáticamente con el sistema                ║
║                                                          ║
╚══════════════════════════════════════════════════════════╝
